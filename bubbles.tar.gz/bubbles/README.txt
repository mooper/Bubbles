Bubble App
An Android App by mooper
Copyright © 2011 Michael D. Hooper 
Source code released under the MIT License 
(http://www.opensource.org/licenses/mit-license.php)
"Source code" means all .java and .xml files. 

Artwork is beta, images taken from google image search, soon to be replaced by my own artwork.  Please change the artwork if you are going to copy or redistribute any part of this application.

Programming and Project Lead, Michael D. Hooper AKA mooper 
Github page: https://github.com/mooper/
Email:       mooper.hooper@gmail.com

This is an android application, it is very simple.  When you run it, it has a bubble floating on the screen.  There are spikes in the upper right corner that will pop the bubble.  In the lower left corner there is a key, if there is only one bubble out and that bubble travels over the key it will release a second bubble.  To end the application, pop both bubbles against the spikes.  This is the beta version changes and improvements to come soon.


